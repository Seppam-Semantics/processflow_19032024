import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { CommonMethods } from 'src/app/shared/functions/common-methods.service';
@Component({
  selector: 'app-business-partner-setup-root',
  templateUrl: './business-partner-setup-root.component.html',
  styleUrls: ['./../../org-setup/org-setup-root/org-setup-root.component.scss'],

})
export class BusinessPartnersetupComponent implements OnInit {

  selectedIndex: number = 0;
  selectedTab: any;
  contactForm: any = FormGroup;
  category = new FormControl;
  subCategory = new FormControl;
  type1 = new FormControl;
  type2 = new FormControl;
  businessfunctionality = new FormControl;
  formField: any;

  userRoleAccess: any;
  businessContactCategory: boolean = false;
  businessContactSubCategory: boolean = false;
  businessContactType1: boolean = false;
  businessContactType2: boolean = false;
  contactCategory:boolean=false;
  contactFunctionality: boolean = false;
  public tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    this.selectedIndex = tabChangeEvent.index;
    this.selectedTab = tabChangeEvent.tab.textLabel;
  }

  public nextStep() {
    this.selectedIndex += 1;
  }

  public previousStep() {
    this.selectedIndex -= 1;
  }


  constructor() {
    this.userRoleAccess = CommonMethods.userContext();
  }
  //{"contactCategory": , "businessContacType2":, "businessContactType1":  "contactFunctionality": "businessContactCategory" "businessContactSubCategory": 
  menuList = ['Business Partner Category', 'Business Partner Sub Category' , 'Business Partner Type 1','Business Partner Type 2', 'Contact Category', 'Contact Functionality'];

  ngOnInit() {
    if (sessionStorage.getItem('role') == '1') {
      this.selectedTab = 'Business Partner Category';
      this.businessContactCategory = true;
      this.businessContactSubCategory = true;
      this.businessContactType1 = true;
      this.businessContactType2 = true;
      this.contactCategory=true
      this.contactFunctionality = true;

    }
    if (sessionStorage.getItem('role') == '2') {
      let profiles: any = this.userRoleAccess.customRole;
      profiles = JSON.parse(profiles);

      profiles.forEach((profile: any): any => {
        profile = profile.contactModule;
        if (profile.businessContactCategory.selection == true || profile.businessContactCategory.creation == true || profile.businessContactCategory.deletion == true ||
          profile.businessContactCategory.updation == true) {
          this.businessContactCategory = true;
          return this.businessContactCategory;
        }

      })
      this.selectedTab = 'Business Partner Category';
    }
    if (sessionStorage.getItem('role') == '2') {
      let profiles: any = this.userRoleAccess.customRole;
      profiles = JSON.parse(profiles);

      profiles.forEach((profile: any): any => {
        profile = profile.contactModule;
        if (profile.businessContactSubCategory.selection == true || profile.businessContactSubCategory.creation == true || profile.businessContactSubCategory.deletion == true ||
          profile.businessContactSubCategory.updation == true) {
          this.businessContactSubCategory = true;
          return this.businessContactSubCategory;
        }

      })


    }
    if (sessionStorage.getItem('role') == '2') {
      let profiles: any = this.userRoleAccess.customRole;
      profiles = JSON.parse(profiles);

      profiles.forEach((profile: any): any => {
        profile = profile.contactModule;
        if (profile.businessContactType1.selection == true || profile.businessContactType1.creation == true || profile.businessContactType1.deletion == true ||
          profile.businessContactType1.updation == true) {
          this.businessContactType1 = true;
          return this.businessContactType1;
        }

      })


    }
    if (sessionStorage.getItem('role') == '2') {
      let profiles: any = this.userRoleAccess.customRole;
      profiles = JSON.parse(profiles);

      profiles.forEach((profile: any): any => {
        profile = profile.contactModule;
        if (profile.businessContactType2.selection == true || profile.businessContactType2.creation == true || profile.businessContactType2.deletion == true ||
          profile.businessContactType2.updation == true) {
          this.businessContactType2 = true;
          return this.businessContactType2;
        }

      })

      if (sessionStorage.getItem('role') == '2') {
        let profiles: any = this.userRoleAccess.customRole;
        profiles = JSON.parse(profiles);

        profiles.forEach((profile: any): any => {
          profile = profile.contactModule;
          if (profile.contactCategory.selection == true || profile.contactCategory.creation == true || profile.contactCategory.deletion == true ||
            profile.contactCategory.updation == true) {
            this.contactCategory = true;
            return this.contactCategory;
          }

        })


      }


      if (sessionStorage.getItem('role') == '2') {
        let profiles: any = this.userRoleAccess.customRole;
        profiles = JSON.parse(profiles);

        profiles.forEach((profile: any): any => {
          profile = profile.contactModule;
          if (profile.contactFunctionality.selection == true || profile.contactFunctionality.creation == true || profile.contactFunctionality.deletion == true ||
            profile.contactFunctionality.updation == true) {
            this.contactFunctionality = true;
            return this.contactFunctionality;
          }

        })


      }


    }

  }
}


