export class Fields{

}