export interface Dept {
  unitId: number;
  code: string;
    name: string;
    description: string;
    active: boolean;
    createdBy: any;
    modifiedBy: any;
  id?: number;
  unitName: string;
}