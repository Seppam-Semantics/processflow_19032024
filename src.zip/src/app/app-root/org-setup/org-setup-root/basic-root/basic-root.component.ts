import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-root',
  templateUrl: './basic-root.component.html',
  styleUrls: ['./basic-root.component.scss']
})
export class BasicRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
