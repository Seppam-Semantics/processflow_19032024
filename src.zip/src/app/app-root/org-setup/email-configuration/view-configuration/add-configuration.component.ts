import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DeptService } from 'src/app/app-root/setup-service/org-setup/dept/dept.service';
import { UnitService } from 'src/app/app-root/setup-service/org-setup/unit/unit.service';
import { NotifierService } from 'src/app/notification/service/notifier.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EamilService } from 'src/app/app-root/setup-service/org-setup/email-configuration/email.service';

@Component({
  selector: 'app-view-configuration',
  templateUrl: './add-configuration.component.html',
  styleUrls: ['./add-configuration.component.scss']
})
export class AddMailConfigurationComponent implements OnInit {

  mailForm:any=FormGroup;
  update:boolean=false;

  constructor(private fb:FormBuilder,
              private org:DeptService,
              private service: EamilService,
              private notification:NotifierService,
              public dialogRef: MatDialogRef<any>,  
              private unit:UnitService,
              @Inject(MAT_DIALOG_DATA) public data:any) { }

  ngOnInit(){
    this.mailForm=this.fb.group({
      username:[],
      password:[],
      host:[],
      port:[]
     })
     if(this.data!=null){
      this.update = true;
      this.editData()
    } 
  }


  editData(){
this.mailForm.patchValue({
  username:this.data.username,
  password: this.data.password,
  host: this.data.host,
  port: this.data.port
    })
  }

  
  updateDept() {
    if (this.mailForm.valid == true) {
  this.data.username = this.mailForm.value.username;
    this.data.password = this.mailForm.value.password;
    this.data.host = this.mailForm.value.host;
    this.data.port = this.mailForm.value.port; 
    this.service.postMail(this.data).subscribe(res => {
      this.dialogRef.close('done');
      this.notification.openSnackBar('Email Updated Successfully', 1);
    })
    this.mailForm.reset();
      
  }
  else {
    this.notification.openSnackBar('Please fill all required fields to continue',0);
  }
}
  

  public addItem(): any {
    if (this.mailForm.valid == true) {
      var dataRow: any = this.mailForm.value;
      this.service.postMail(dataRow).subscribe(data => {
        this.dialogRef.close(data);
        this.notification.openSnackBar('Mail Config Added Successfully', 1);
      })
      this.mailForm.reset();
    
    }
    else {
      this.notification.openSnackBar('Please fill all required fields to continue',0);
    }
  }

}
