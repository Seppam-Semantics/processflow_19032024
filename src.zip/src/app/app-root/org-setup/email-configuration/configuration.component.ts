import { Component, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PageEvent, MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { of } from 'rxjs';
import { catchError, delay, map } from 'rxjs/operators';
import { NotifierService } from 'src/app/notification/service/notifier.service';
import { ConfirmDeleteComponent } from 'src/app/shared/confirm-delete/confirm-delete.component';
import { CommonMethods } from 'src/app/shared/functions/common-methods.service';
import { DeptService } from '../../setup-service/org-setup/dept/dept.service';
import { AddMailConfigurationComponent } from './view-configuration/add-configuration.component';
import { EamilService } from '../../setup-service/org-setup/email-configuration/email.service';


@Component({
  selector: 'app-email-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.scss']
})
export class MailConfigurationComponent {

  mail$ = this.getMail();

  searchText: any;
  orderHeader: any;
  isDescOrder: boolean = true;
  isEmpty!: boolean;
  $department: any;
  $unit: any;

  creation!: boolean;
  selection!: boolean;
  updation!: boolean;
  deletion!: boolean;

  displayedColumns: string[] = ['username', 'password', 'host','port', 'action'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(
    private dialog: MatDialog,
    private notification: NotifierService,
    private service: EamilService) {
    this.dataSource = new MatTableDataSource();

  }

  sortData(data: any) {
    data.sort = this.sort;
  }


  isEnable(permision: any) {
    return CommonMethods.userRole('organizationModule', 'emailConfiguration', permision);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }



  getMail(data?: PageEvent) {
    return this.service.geMail().pipe(
      delay(300),
      map(department => {
        this.dataSource = new MatTableDataSource(department.data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.data = department.data;
        return true;
      }),

      catchError(() => of('error')))

  }

  deleteItem(data: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let confirmDelete = this.dialog.open(ConfirmDeleteComponent, dialogConfig);
    confirmDelete.afterClosed().subscribe(result => {
      if (result == 'true') {
        this.service.deleteMail(data).subscribe(
          (res: any) => {
            if (res.success) {
              this.notification.openSnackBar('Email Deleted Successfully', 2);
              this.mail$ = this.getMail();
            } else return;
          },
          (error: any) => {
            this.notification.openSnackBar('An error occurred while deleting the Department', 2);
          }
        );
      } 
    })
  }

  edit(data: any) {
    this.dialog.open(AddMailConfigurationComponent, { data: data });
  }


 



  addNew() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dept = this.dialog.open(AddMailConfigurationComponent, dialogConfig);
    dept.afterClosed().subscribe(res => {
      if (res) {
        this.mail$ = this.getMail();
      }
    });
  }



}
