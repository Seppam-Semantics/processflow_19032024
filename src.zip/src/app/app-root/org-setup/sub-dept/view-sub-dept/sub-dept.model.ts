export interface SubDept {
    departmentId?: number;

    departmentCode: string;
    code: string;
    name: string;
    description: string;
    active: boolean;
    createdBy: any;
    modifiedBy: any;
    id?:number;
}