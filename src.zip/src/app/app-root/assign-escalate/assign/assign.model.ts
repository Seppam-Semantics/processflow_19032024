export interface Assign {
  [x: string]: any;
  id: number;
  typeId: number
  priority: number
  department: number
  count: number
  shareWith: number
  selectedValue:string 
  setup: Setup
  employees: any
  active: boolean
  createdBy: string
  modifiedBy: string
}

export interface Setup {
  id: string
}
export interface TypeId {
  id: number
}
export interface Employee {
  id: number
}