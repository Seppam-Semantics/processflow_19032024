import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AssignService } from 'src/app/app-root/setup-service/assign-setup/assign/assign.service';
import { EmployeeService } from 'src/app/app-root/setup-service/emp-setup/employee/employee.service';
import { DeptService } from 'src/app/app-root/setup-service/org-setup/dept/dept.service';
import { PriorityService } from 'src/app/app-root/setup-service/task-master-setup/priority/priority.service';
import { TypeService } from 'src/app/app-root/setup-service/task-master-setup/type/type.service';
import { NotifierService } from 'src/app/notification/service/notifier.service';
import { Assign } from '../assign.model';
import { catchError, map } from 'rxjs/operators';
import { WorkingGroupService } from 'src/app/app-root/setup-service/org-setup/working-group/working-group.service';
import { CommonMethods } from 'src/app/shared/functions/common-methods.service';
import { EmpGroupService } from 'src/app/app-root/setup-service/org-setup/emp-group/emp-group.service';

@Component({
  selector: 'app-add-assign',
  templateUrl: './add-assign.component.html',
  styleUrls: ['./add-assign.component.scss'],
})
export class AddAssignComponent implements OnInit {
  department$ = this.department.department$;
  type$ = this.taskTypes.type$;
  employee$ = this.emp.employee$;
  priority$ =this.priorities.taskPriority$;
  searchTypeId!: string;
  assignForm: any = FormGroup;
  escalateSharingForm: any = FormGroup;
  selectedValue!: string ;
  taskType: any;
  priority: any;
  dept: any;
  employee: any;
  update!: boolean;
  shareWithUser:any
  shareWith:any
  type: any;
  empObj: any;
  userContext = CommonMethods.userContext();


  empId = sessionStorage.getItem('empId')

  currentUser$ = this.emp.employee$.pipe(map(employees =>{
    return this.empObj =employees.filter((emp: any) => emp.id == Number(this.empId))[0];
  }
  ));

  empGroup$ = this.empGroup.empgroup$;
  sharedWith: any;

  
  constructor(
    private fb: FormBuilder,
    private service: AssignService,
    private empGroup: EmpGroupService,
    private taskTypes: TypeService,
    private priorities: PriorityService,
    private department: DeptService,
    private emp: EmployeeService,
    private notification: NotifierService,
    private dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: Assign
  ) {

  }

  ngOnInit(): void {


    this.assignForm = this.fb.group({
      typeId: [],
      priority: [],
      department: [],
      count: [],
      shareWith: ['', Validators.required], // Define validators as needed
      shareWithEmp:[],
      shareWithWorkingGroup:[],
      shareWithHierarchy:[]
    });

   


   

    if (this.data != null) {
      this.update = true;
      this.editData();
    }

    this.selectedValue = this.data.sharedWith.toString();;

  }

  editData() {
    this.assignForm.patchValue({
      typeId: this.data.taskTypeId,
      priority: this.data.priorityId,
      department: this.data.departmentId,
      count: this.data.e_rank,
      shareWith:this.data.sharedWith,
      shareWithEmp:this.data.escalateEmp ? this.getEmp(this.data.escalateEmp) : 0,
      shareWithWorkingGroup:this.data.escalateEmpGroup ? this.getEmpGroup(this.data.escalateEmpGroup) :0,
      shareWithHierarchy:this.currentUser$ 
    });
  }

  getEmp(employees: any) {
    let arr: any[] = [];
    if (employees.length > 0) {
      employees.map((category: any) => {
        arr.push(category.empId);
      })
    }
    return arr;
  }
  
  getEmpGroup(employeeGroup: any) {
    let arr: any[] = [];
    if (employeeGroup.length > 0) {
      employeeGroup.map((category: any) => {
        arr.push(category.empGroupId);
      })
    }
    return arr;
  }
  


  updateAssign() {
  //  let dataRow = this.assignForm.value;
    let dataRow=this.data;
    dataRow.id = this.data.id;
    dataRow.typeId = this.assignForm.value.typeId;
    dataRow.priority = this.assignForm.value.priority;
    dataRow.department = this.assignForm.value.department;
    dataRow.count = this.assignForm.value.count;
    dataRow.shareWith = this.assignForm.value.shareWith;
    if(dataRow.shareWith==1){
      dataRow.shareWithEmp = this.assignForm.value.shareWithEmp;
    }
   if (dataRow.shareWith==2){
      dataRow.shareWithWorkingGroup = this.assignForm.value.shareWithWorkingGroup;
    }

    this.service.postAssign(dataRow).subscribe((res: any) => {
      this.dialogRef.close('done');
      this.notification.openSnackBar(' Updated Successfully', 1);
    });
    this.assignForm.reset();
  }

  public addItem(): any {
    let dataRow: any = this.assignForm.value;
    if(this.assignForm.valid == true) {
      this.service.postAssign(dataRow).subscribe((res:any) => {
       this.dialogRef.close(res);
        this.notification.openSnackBar(' Added Successfully', 1);
      });
      this.assignForm.reset();
    } 
    else {
      this.notification.openSnackBar('Please fill all required fields to continue',0)
    }
  }
  
}
