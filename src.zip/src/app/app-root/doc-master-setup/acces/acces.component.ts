import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acces',
  templateUrl: './acces.component.html',
  styleUrls: ['./acces.component.scss']
})
export class AccesComponent implements OnInit {
  

  constructor(
 
  ) { }

  ngOnInit(): void {
  }


}
