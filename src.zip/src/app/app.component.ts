import { Component, HostListener, OnInit } from '@angular/core';
import { AuthService } from './services/auth/authentication/auth.service';
import { interval } from 'rxjs';
import { CountryService } from './services/country.service';
import { environment } from 'src/environments/environment';
import { timer } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Otomate';
  intervalSubscription: any;
  http: any;
  isLoading: boolean = true;

  constructor(private auth: AuthService, private configService: CountryService) {

  }
  ngOnInit(): void {
    this.configService.getConfig().subscribe((data: any) => {
      //console.log(data);
      environment.AUTH_URL = data.AUTH_URL;
      environment.ORG_URL = data.ORG_URL;
      environment.ROLE_URL = data.ROLE_URL;
      environment.EMP_URL = data.EMP_URL;
      environment.CONTACT_URL = data.CONTACT_URL;
      environment.PROJECT_URL = data.PROJECT_URL;
      environment.DOC_URL = data.DOC_URL;
      environment.TASK_URL = data.TASK_URL;
      environment.TMS_URL = data.TMS_URL;
      environment.DMS_URL = data.DMS_URL;
      environment.CRON_URL = data.CRON_URL;
      timer(400).subscribe(() => {
        this.isLoading = false;
      });

      // this.isLoading = false; 
      // return data;
    });
  }
  @HostListener('contextmenu', ['$event'])
  onRightClick(event: MouseEvent) {
    event.preventDefault();
  }

}
